package web.dispatcher;

public class Navi {
	   public static String home = "<a href='main.cacao'>HOME</a>";
	   public static String register = home + " > register";
	   public static String about = home + " > about us";
	   public static String userAdd = home + " > user add";
	   public static String userlist = home + " > User List";
	   public static String userdetail = home + " > User Detail";
	   public static String userupdate = home + " > User Update";
	   public static String productAdd = home + " > product add";
	   public static String registerok = home + " > register ok";
	   public static String registerfail = home + " > register fail";
	   public static String productlist = home + " > Product List";
	   public static String productdetail = home + " > Product Detail";
	   public static String productupdate = home + " > Product Update";
	   
}






